package com.example.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import com.example.data.AppDatabase
import com.example.data.model.RevisionSession
import com.example.data.repository.RevisionSyncManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

private const val ACTION_WIDGET_DONE = "com.example.action.REVISION_WIDGET_DONE"
private const val EXTRA_SESSION_ID = "session_id"

abstract class RevisionWidgetProvider : AppWidgetProvider() {
    protected abstract fun widgetType(): Type
    enum class Type { TODAY, TWO_DAY, NEXT, PROGRESS }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        updateAll(context)
    }

    override fun onEnabled(context: Context) {
        updateAll(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_WIDGET_DONE) {
            val id = intent.getStringExtra(EXTRA_SESSION_ID) ?: return
            val pending = goAsync()
            CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
                try {
                    AppDatabase.getDatabase(context).revisionSessionDao()
                        .markCompleted(id, System.currentTimeMillis())
                } finally {
                    pending.finish()
                }
                updateAll(context)
            }
        } else if (intent.action == AppWidgetManager.ACTION_APPWIDGET_UPDATE ||
            intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == "com.example.action.REVISION_WIDGET_REFRESH") {
            updateAll(context)
        }
    }

    companion object {
        fun updateAll(context: Context) {
            CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
                val db = AppDatabase.getDatabase(context)
                val sessions = db.revisionSessionDao().getPendingForDates(
                    listOf(RevisionSyncManager.dateOffset(0), RevisionSyncManager.dateOffset(1))
                )
                val manager = AppWidgetManager.getInstance(context)
                listOf(
                    TodayRevisionWidget::class.java,
                    TwoDayRevisionWidget::class.java,
                    NextRevisionWidget::class.java,
                    RevisionProgressWidget::class.java
                ).forEach { provider ->
                    val ids = manager.getAppWidgetIds(ComponentName(context, provider))
                    ids.forEach { id ->
                        val type = when (provider) {
                            TodayRevisionWidget::class.java -> Type.TODAY
                            TwoDayRevisionWidget::class.java -> Type.TWO_DAY
                            NextRevisionWidget::class.java -> Type.NEXT
                            else -> Type.PROGRESS
                        }
                        manager.updateAppWidget(id, buildViews(context, type, sessions))
                    }
                }
            }
        }

        private fun buildViews(context: Context, type: Type, sessions: List<RevisionSession>): RemoteViews {
            val views = RemoteViews(context.packageName, R.layout.widget_revision)
            val today = RevisionSyncManager.dateOffset(0)
            val tomorrow = RevisionSyncManager.dateOffset(1)
            val todaySessions = sessions.filter { it.date == today }
            val tomorrowSessions = sessions.filter { it.date == tomorrow }

            val title = when (type) {
                Type.TODAY -> "⚡ TODAY'S REVISION"
                Type.TWO_DAY -> "📅 2-DAY REVISION"
                Type.NEXT -> "🎯 NEXT SESSION"
                Type.PROGRESS -> "📊 REVISION PROGRESS"
            }
            views.setTextViewText(R.id.widget_title, title)

            when (type) {
                Type.TODAY -> {
                    views.setTextViewText(R.id.widget_summary, if (todaySessions.isEmpty()) "No pending sessions today" else "${todaySessions.size} session${if (todaySessions.size == 1) "" else "s"} pending")
                    renderLines(views, todaySessions.take(3))
                }
                Type.TWO_DAY -> {
                    views.setTextViewText(R.id.widget_summary, "Today ${todaySessions.size}  •  Tomorrow ${tomorrowSessions.size}")
                    renderLines(views, (todaySessions + tomorrowSessions).take(4))
                }
                Type.NEXT -> {
                    val next = sessions.firstOrNull()
                    if (next == null) {
                        views.setTextViewText(R.id.widget_summary, "No pending revision")
                        renderLines(views, emptyList())
                    } else {
                        views.setTextViewText(R.id.widget_summary, "${next.subject}  •  ${next.durationMinutes} min")
                        renderLines(views, listOf(next))
                    }
                }
                Type.PROGRESS -> {
                    val total = sessions.size
                    views.setTextViewText(R.id.widget_summary, if (total == 0) "All 1–2 day sessions complete" else "$total pending • next 2 days only")
                    renderLines(views, sessions.take(4))
                }
            }

            val openIntent = PendingIntent.getActivity(
                context, type.ordinal + 1000,
                Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, openIntent)

            val first = sessions.firstOrNull()
            if (first != null) {
                val doneIntent = Intent(context, TodayRevisionWidget::class.java).apply {
                    action = ACTION_WIDGET_DONE
                    putExtra(EXTRA_SESSION_ID, first.id)
                }
                val donePending = PendingIntent.getBroadcast(
                    context, (first.id.hashCode() xor type.ordinal), doneIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_done, donePending)
                views.setTextViewText(R.id.widget_done, "✓ Done")
            } else {
                views.setTextViewText(R.id.widget_done, "Open app")
            }
            return views
        }

        private fun renderLines(views: RemoteViews, list: List<RevisionSession>) {
            val text = if (list.isEmpty()) "Nothing scheduled" else list.joinToString("\n") {
                val day = if (it.date == RevisionSyncManager.dateOffset(0)) "Today" else "Tomorrow"
                "• ${it.subject} — ${it.chapter} · ${it.durationMinutes}m ($day)"
            }
            views.setTextViewText(R.id.widget_sessions, text)
        }
    }
}

class TodayRevisionWidget : RevisionWidgetProvider() { override fun widgetType() = Type.TODAY }
class TwoDayRevisionWidget : RevisionWidgetProvider() { override fun widgetType() = Type.TWO_DAY }
class NextRevisionWidget : RevisionWidgetProvider() { override fun widgetType() = Type.NEXT }
class RevisionProgressWidget : RevisionWidgetProvider() { override fun widgetType() = Type.PROGRESS }
