package com.example.notification

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.media.AudioAttributes
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.model.CustomNotification
import com.example.data.model.NotificationPriority
import com.example.data.model.RepeatMode
import com.example.data.model.RevisionSession
import com.example.data.repository.RevisionSyncManager
import com.example.receiver.NotificationActionReceiver
import com.example.receiver.NotificationReceiver
import java.util.Calendar

object NotificationHelper {
    const val CHANNEL_HIGH_ID = "custom_notify_high"
    const val CHANNEL_DEFAULT_ID = "custom_notify_default"
    const val CHANNEL_LOW_ID = "custom_notify_low"
    // Dedicated revision channel. A new ID is intentional so devices that previously
    // had the revision channel muted/silent do not inherit that old channel state.
    const val CHANNEL_REVISION_ID = "revision_sessions_alerts_v2"

    const val EXTRA_NOTIFICATION_ID = "extra_notification_id"
    const val EXTRA_TITLE = "extra_title"
    const val EXTRA_MESSAGE = "extra_message"
    const val EXTRA_CATEGORY = "extra_category"
    const val EXTRA_REVISION_SESSION_ID = "extra_revision_session_id"

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val highChannel = NotificationChannel(
                CHANNEL_HIGH_ID,
                "Urgent Reminders",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "High priority reminders with pop-up banner and sound"
                enableVibration(true)
                enableLights(true)
            }

            val defaultChannel = NotificationChannel(
                CHANNEL_DEFAULT_ID,
                "Standard Notifications",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Standard custom notifications"
            }

            val lowChannel = NotificationChannel(
                CHANNEL_LOW_ID,
                "Silent Alerts",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Silent background notifications"
            }

            val revisionChannel = NotificationChannel(
                CHANNEL_REVISION_ID,
                "Revision Session Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Audible and vibrating alerts for scheduled JEE revision sessions"
                val soundUri = android.provider.Settings.System.DEFAULT_NOTIFICATION_URI
                val audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                setSound(soundUri, audioAttributes)
                enableVibration(true)
                vibrationPattern = longArrayOf(0L, 300L, 180L, 450L)
                enableLights(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            notificationManager.createNotificationChannels(
                listOf(highChannel, defaultChannel, lowChannel, revisionChannel)
            )
        }
    }

    fun scheduleAlarm(context: Context, notification: CustomNotification) {
        if (!notification.isEnabled) return

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, NotificationReceiver::class.java).apply {
            putExtra(EXTRA_NOTIFICATION_ID, notification.id)
            putExtra(EXTRA_TITLE, notification.title)
            putExtra(EXTRA_MESSAGE, notification.message)
            putExtra(EXTRA_CATEGORY, notification.category.name)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            notification.id.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        var triggerTime = notification.triggerTimeMillis
        val now = System.currentTimeMillis()

        if (triggerTime <= now) {
            triggerTime = getNextTriggerTime(notification.triggerTimeMillis, notification.repeatMode)
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    if (alarmManager.canScheduleExactAlarms()) {
                        alarmManager.setExactAndAllowWhileIdle(
                            AlarmManager.RTC_WAKEUP,
                            triggerTime,
                            pendingIntent
                        )
                    } else {
                        alarmManager.setAndAllowWhileIdle(
                            AlarmManager.RTC_WAKEUP,
                            triggerTime,
                            pendingIntent
                        )
                    }
                } else {
                    alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerTime,
                        pendingIntent
                    )
                }
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    triggerTime,
                    pendingIntent
                )
            }
        } catch (e: SecurityException) {
            alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                triggerTime,
                pendingIntent
            )
        }
    }

    fun cancelAlarm(context: Context, notificationId: Long) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, NotificationReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            notificationId.toInt(),
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }
    }

    fun showNotification(
        context: Context,
        id: Long,
        title: String,
        message: String,
        category: String = "GENERAL",
        priority: NotificationPriority = NotificationPriority.HIGH
    ) {
        val channelId = when (priority) {
            NotificationPriority.HIGH -> CHANNEL_HIGH_ID
            NotificationPriority.DEFAULT -> CHANNEL_DEFAULT_ID
            NotificationPriority.LOW -> CHANNEL_LOW_ID
        }

        val contentIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            context,
            id.toInt(),
            contentIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val snoozeIntent = Intent(context, NotificationActionReceiver::class.java).apply {
            action = "ACTION_SNOOZE"
            putExtra(EXTRA_NOTIFICATION_ID, id)
            putExtra(EXTRA_TITLE, title)
            putExtra(EXTRA_MESSAGE, message)
        }
        val snoozePendingIntent = PendingIntent.getBroadcast(
            context,
            (id * 1000 + 1).toInt(),
            snoozeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val doneIntent = Intent(context, NotificationActionReceiver::class.java).apply {
            action = "ACTION_MARK_DONE"
            putExtra(EXTRA_NOTIFICATION_ID, id)
        }
        val donePendingIntent = PendingIntent.getBroadcast(
            context,
            (id * 1000 + 2).toInt(),
            doneIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(
                when (priority) {
                    NotificationPriority.HIGH -> NotificationCompat.PRIORITY_HIGH
                    NotificationPriority.DEFAULT -> NotificationCompat.PRIORITY_DEFAULT
                    NotificationPriority.LOW -> NotificationCompat.PRIORITY_LOW
                }
            )
            .setAutoCancel(true)
            .setContentIntent(contentPendingIntent)
            .addAction(0, "Snooze 10m", snoozePendingIntent)
            .addAction(0, "Mark Done", donePendingIntent)

        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(id.toInt(), builder.build())
    }

    fun scheduleRevisionSession(context: Context, session: RevisionSession, slotIndex: Int) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val trigger = Calendar.getInstance().apply {
            val parts = session.date.split("-")
            if (parts.size == 3) {
                set(Calendar.YEAR, parts[0].toIntOrNull() ?: get(Calendar.YEAR))
                set(Calendar.MONTH, (parts[1].toIntOrNull() ?: (get(Calendar.MONTH) + 1)) - 1)
                set(Calendar.DAY_OF_MONTH, parts[2].toIntOrNull() ?: get(Calendar.DAY_OF_MONTH))
            }
            set(Calendar.HOUR_OF_DAY, 9 + (slotIndex % 6))
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        var triggerTime = trigger.timeInMillis
        val now = System.currentTimeMillis()
        if (triggerTime <= now) {
            // If today's planned time has already passed, remind shortly instead
            // of silently losing the session.
            if (session.date == RevisionSyncManager.dateOffset(0)) {
                triggerTime = now + 60_000L
            } else {
                return
            }
        }

        val intent = Intent(context, RevisionSessionNotificationReceiver::class.java).apply {
            putExtra(EXTRA_REVISION_SESSION_ID, session.id)
            putExtra(EXTRA_TITLE, "⚡ Revision Session")
            putExtra(
                EXTRA_MESSAGE,
                "${session.subject} — ${session.chapter} · ${session.durationMinutes} min"
            )
            putExtra(EXTRA_CATEGORY, "REVISION")
        }
        val requestCode = ("rev:" + session.id).hashCode()
        val pendingIntent = PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent)
                } else {
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent)
                }
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent)
            }
        } catch (_: SecurityException) {
            alarmManager.set(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent)
        }
    }

    fun cancelRevisionSession(context: Context, sessionId: String) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, RevisionSessionNotificationReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context, ("rev:" + sessionId).hashCode(), intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        pendingIntent?.let {
            alarmManager.cancel(it)
            it.cancel()
        }
    }

    fun showRevisionNotification(context: Context, sessionId: String, title: String, message: String) {
        val contentIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            context, ("rev-open:" + sessionId).hashCode(), contentIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val doneIntent = Intent(context, NotificationActionReceiver::class.java).apply {
            action = "ACTION_REVISION_DONE"
            putExtra(EXTRA_REVISION_SESSION_ID, sessionId)
        }
        val donePendingIntent = PendingIntent.getBroadcast(
            context, ("rev-done:" + sessionId).hashCode(), doneIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notificationId = ("revision:" + sessionId).hashCode()
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // On Android 8+, sound/vibration are controlled by the notification channel.
        // The dedicated revision channel is IMPORTANCE_HIGH and explicitly configured
        // with the system notification sound + vibration pattern.
        val builder = NotificationCompat.Builder(context, CHANNEL_REVISION_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setDefaults(NotificationCompat.DEFAULT_SOUND or NotificationCompat.DEFAULT_VIBRATE)
            .setVibrate(longArrayOf(0L, 300L, 180L, 450L))
            .setAutoCancel(true)
            .setContentIntent(contentPendingIntent)
            .addAction(0, "Mark Done", donePendingIntent)
        manager.notify(notificationId, builder.build())
    }

    fun getNextTriggerTime(initialTimeMillis: Long, repeatMode: RepeatMode): Long {
        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply { timeInMillis = initialTimeMillis }

        if (repeatMode == RepeatMode.ONCE) {
            return if (target.before(now)) now.timeInMillis + 5000 else target.timeInMillis
        }

        while (target.before(now)) {
            when (repeatMode) {
                RepeatMode.ONCE -> break
                RepeatMode.EVERY_5_MINS -> target.add(Calendar.MINUTE, 5)
                RepeatMode.HOURLY -> target.add(Calendar.HOUR_OF_DAY, 1)
                RepeatMode.DAILY -> target.add(Calendar.DAY_OF_YEAR, 1)
                RepeatMode.WEEKLY -> target.add(Calendar.DAY_OF_YEAR, 7)
                RepeatMode.MON_FRI -> {
                    target.add(Calendar.DAY_OF_YEAR, 1)
                    while (target.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY ||
                        target.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY
                    ) {
                        target.add(Calendar.DAY_OF_YEAR, 1)
                    }
                }
                RepeatMode.WEEKENDS -> {
                    target.add(Calendar.DAY_OF_YEAR, 1)
                    while (target.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY &&
                        target.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY
                    ) {
                        target.add(Calendar.DAY_OF_YEAR, 1)
                    }
                }
            }
        }
        return target.timeInMillis
    }
}
