package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.data.dao.CustomNotificationDao
import com.example.data.dao.NotificationLogDao
import com.example.data.dao.RevisionSessionDao
import com.example.data.model.CustomNotification
import com.example.data.model.NotificationLog
import com.example.data.model.RevisionSession

@Database(
    entities = [CustomNotification::class, NotificationLog::class, RevisionSession::class],
    version = 2,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun notificationDao(): CustomNotificationDao
    abstract fun logDao(): NotificationLogDao
    abstract fun revisionSessionDao(): RevisionSessionDao

    companion object {
        private val MIGRATION_1_2 = object : androidx.room.migration.Migration(1, 2) {
            override fun migrate(database: androidx.sqlite.db.SupportSQLiteDatabase) {
                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS revision_sessions (
                        id TEXT NOT NULL PRIMARY KEY,
                        analysisId TEXT NOT NULL,
                        testName TEXT NOT NULL,
                        subject TEXT NOT NULL,
                        chapter TEXT NOT NULL,
                        topic TEXT,
                        priority TEXT NOT NULL,
                        reason TEXT NOT NULL,
                        mistakeType TEXT,
                        questions TEXT,
                        date TEXT NOT NULL,
                        durationMinutes INTEGER NOT NULL,
                        status TEXT NOT NULL,
                        source TEXT NOT NULL,
                        createdAt INTEGER NOT NULL,
                        completedAt INTEGER
                    )
                    """.trimIndent()
                )
            }
        }

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "custom_notifications_db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
