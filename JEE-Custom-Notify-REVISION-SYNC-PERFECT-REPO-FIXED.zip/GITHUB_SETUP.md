# Notify — GitHub setup

## Create the repository
1. Create a new empty GitHub repository.
2. Upload **the contents of this folder**, not this ZIP file.
3. The repository root must contain `app/`, `gradle/`, `build.gradle.kts`, `settings.gradle.kts`, and `.github/`.
4. Do not upload `source.zip`. No unzip step is needed.

## Build
The included `.github/workflows/build-android.yml` builds automatically on every push to `main`, or manually from Actions → Build Android APK → Run workflow.

## Get the APK
Open the successful workflow run → Artifacts → `Notify-debug-apk` → download it.

## Revision sync
The Test Analysis page in `web/test-analysis.html` can send a 1–2 day plan to the installed app through the `customnotify://revision-sync` deep link. The Android app rejects dates outside today and tomorrow.

## Important
This build intentionally does not require `google-services.json` for the revision-sync/notification functionality. The previous build failed because the Google Services Gradle plugin was being applied without that file. Gemini personalization uses the direct HTTP API fallback already present in the project and does not require the Firebase Gradle plugin.
